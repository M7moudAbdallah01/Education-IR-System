# Member 2: raw TF, weighted TF, DF and IDF
#
#   weighted TF = 1 + log10(TF) for TF > 0
#   IDF         = log10(N / DF)
#
# The documents are taken from the positional index itself, so the module works
# for any dataset (any number of documents, any file names).
import csv
import json
import math
import os
import re
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent.parent
DEFAULT_OUTPUT_DIR = str(BASE_DIR / "output")
INDEX_PATH = BASE_DIR / "output" / "positional_index.json"  # kept for compatibility


def _doc_order(doc):
    """Natural sort so that d2 comes before d10."""
    return tuple(
        (0, int(p)) if p.isdigit() else (1, p.lower())
        for p in re.split(r"(\d+)", str(doc)) if p != ""
    )


def load_index(path=None):
    with open(path or INDEX_PATH, "r", encoding="utf-8") as file:
        return json.load(file)


def documents_from(positional_index):
    docs = set()
    for postings in positional_index.values():
        docs.update(postings)
    return sorted(docs, key=_doc_order)


def compute(positional_index, documents=None):
    """Return (documents, raw_tf, weighted_tf, df_table) for a positional index."""
    documents = documents or documents_from(positional_index)
    N = len(documents)

    raw_tf, weighted_tf, df_table = {}, {}, {}

    for term, doc_positions in positional_index.items():
        raw_tf[term] = {}
        weighted_tf[term] = {}

        for doc in documents:
            tf = len(doc_positions.get(doc, []))
            raw_tf[term][doc] = tf
            weighted_tf[term][doc] = 1 + math.log10(tf) if tf > 0 else 0

        df = sum(1 for doc in documents if raw_tf[term][doc] > 0)
        idf = math.log10(N / df) if df > 0 else 0
        df_table[term] = {"DF": df, "IDF": idf}

    return documents, raw_tf, weighted_tf, df_table


def print_results(raw_tf, weighted_tf, df_table):
    print("\n========== RAW TF MATRIX ==========")
    for term, values in raw_tf.items():
        print(term, values)

    print("\n========== WEIGHTED TF MATRIX ==========")
    for term, values in weighted_tf.items():
        print(term, {doc: round(value, 4) for doc, value in values.items()})

    print("\n========== DF AND IDF ==========")
    for term, values in df_table.items():
        print(term, "DF =", values["DF"], "IDF =", round(values["IDF"], 4))


def _save_matrix(path, documents, matrix):
    with open(path, "w", newline="", encoding="utf-8-sig") as file:
        writer = csv.writer(file)
        writer.writerow(["term"] + documents)
        for term, values in matrix.items():
            writer.writerow([term] + [round(values[doc], 4) for doc in documents])


def save_results(output_dir, documents, raw_tf, weighted_tf, df_table):
    os.makedirs(output_dir, exist_ok=True)

    _save_matrix(os.path.join(output_dir, "raw_tf.csv"), documents, raw_tf)
    _save_matrix(os.path.join(output_dir, "weighted_tf.csv"), documents, weighted_tf)

    with open(os.path.join(output_dir, "df_idf.csv"), "w",
              newline="", encoding="utf-8-sig") as file:
        writer = csv.writer(file)
        writer.writerow(["term", "DF", "IDF"])
        for term, values in df_table.items():
            writer.writerow([term, values["DF"], round(values["IDF"], 4)])


def run_all(output_dir=None, index_path=None, verbose=True, save=True):
    """
    Read <output_dir>/positional_index.json (or index_path), compute TF / weighted
    TF / DF / IDF and save raw_tf.csv, weighted_tf.csv and df_idf.csv in output_dir.
    """
    output_dir = str(output_dir or DEFAULT_OUTPUT_DIR)
    index_path = index_path or os.path.join(output_dir, "positional_index.json")

    documents, raw_tf, weighted_tf, df_table = compute(load_index(index_path))

    if verbose:
        print_results(raw_tf, weighted_tf, df_table)

    if save:
        save_results(output_dir, documents, raw_tf, weighted_tf, df_table)
        if verbose:
            print("\nCSV files saved in: " + output_dir)

    return documents, raw_tf, weighted_tf, df_table


# ---------------------------------------------------------------------------
# Backward compatibility: test_results.py reads tf_df_idf.raw_tf / weighted_tf /
# df_table for the default dataset right after importing this module.
# ---------------------------------------------------------------------------
try:
    documents, raw_tf, weighted_tf, df_table = compute(load_index(INDEX_PATH))
    N = len(documents)
except (OSError, ValueError):
    documents, raw_tf, weighted_tf, df_table, N = [], {}, {}, {}, 0


if __name__ == "__main__":
    run_all()