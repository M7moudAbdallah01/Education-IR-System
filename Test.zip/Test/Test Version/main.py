#Member 6: runs everything in order

# ---------------------------------------------------------
# Main Integration Program (Member 6)
# Runs Part A (Positional Index with Spark), followed by
# every step of Part B in exact logical order.
# ---------------------------------------------------------

import os
import sys

from partA.positional_index_spark import main as run_part_a
from partB import tf_df_idf
from partB import tfidf_normalization
from partB.phrase_boolean import run_phrase_boolean_queries
from partB.similarity_ranking import run_all as run_similarity_ranking

PROJECT_ROOT = os.path.dirname(os.path.abspath(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)
DEFAULT_OUTPUT_DIR = os.path.join(PROJECT_ROOT, "output")  

def main(dataset_dir=None, output_dir=None):
    print("=========================================================")
    print("   EDUCATION INFORMATION RETRIEVAL SYSTEM - PIPELINE")
    print("=========================================================")

    #dataset_dir : folder with the .txt documents (default: the project's Dataset folder)
    #output_dir  : folder that receives every result file (default: project "output")
    
    custom_run = dataset_dir is not None  # False if using default Dataset folder, True if user specified a dataset folder
    output_dir = os.path.abspath(output_dir or DEFAULT_OUTPUT_DIR)
    index_file = os.path.join(output_dir, "positional_index.json")
    os.makedirs(output_dir, exist_ok=True)



    # -----------------------------------------------------
    # Step 1: Part A - Build & Save Positional Index (Spark)
    # -----------------------------------------------------
    print("\n>>> STEP 1: Running Part A (Positional Index via Spark)...")
    try:
        run_part_a(dataset_dir=dataset_dir, output_dir=output_dir)
    except Exception as exc:
        if not custom_run and os.path.exists(index_file):
            print(f"Spark skipped ({type(exc).__name__}); using existing positional_index.json.")
        else:
            raise

    # -----------------------------------------------------
    # Step 2: Part B (Member 2) - Raw TF, Weighted TF, DF & IDF
    # -----------------------------------------------------
    print("\n>>> STEP 2: Running Part B - Member 2 (TF, Weighted TF, DF & IDF)...")
    tf_df_idf.run_all(output_dir=output_dir, verbose=True, save=True)

    # -----------------------------------------------------
    # Step 3: Part B (Member 3) - TF-IDF & Normalization
    # -----------------------------------------------------
    print("\n>>> STEP 3: Running Part B - Member 3 (TF-IDF & Normalization)...")
    tfidf_normalization.run_all(output_dir=output_dir, verbose=True, save=True)

    # -----------------------------------------------------
    # Step 4: Part B (Member 4) - Phrase & Boolean Queries
    # -----------------------------------------------------
    print("\n>>> STEP 4: Running Part B - Member 4 (Phrase & Boolean Queries)...")
    run_phrase_boolean_queries(index_path=index_file, verbose=True)

    # -----------------------------------------------------
    # Step 5: Part B (Member 5) - Query Vectors, Similarity & Ranking
    # -----------------------------------------------------
    print("\n>>> STEP 5: Running Part B - Member 5 (Cosine Similarity & Ranking)...")
    run_similarity_ranking(verbose=True, save=True, use_csv=True, output_dir=output_dir)

    print("\n=========================================================")
    print("   ALL PIPELINE STEPS COMPLETED SUCCESSFULLY!")
    print("=========================================================")

if __name__ == "__main__":
    # python main.py <dataset_folder> [output_folder]
    args = sys.argv[1:]
    main(dataset_dir=args[0] if args else None,output_dir=args[1] if len(args) > 1 else None)