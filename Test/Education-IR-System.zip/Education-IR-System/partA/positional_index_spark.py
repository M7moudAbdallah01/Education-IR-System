import json
import os
import re
import sys

from pyspark.sql import SparkSession

PROJECT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def _find_default_dataset():
    for name in os.listdir(PROJECT_ROOT):
        if name.lower() == "dataset" and os.path.isdir(os.path.join(PROJECT_ROOT, name)):
            return os.path.join(PROJECT_ROOT, name)
    return os.path.join(PROJECT_ROOT, "Dataset")


DATA_DIR = _find_default_dataset()
OUTPUT_FILE = os.path.join(PROJECT_ROOT, "output", "positional_index.json")


def doc_sort_key(doc_id):
    return tuple(
        (0, int(part), "") if part.isdigit() else (1, 0, part.lower())
        for part in re.split(r"(\d+)", str(doc_id)) if part != ""
    )


def list_documents(dataset_dir):
    """All .txt files directly inside dataset_dir, in natural order."""
    paths = [
        os.path.abspath(os.path.join(dataset_dir, name))
        for name in os.listdir(dataset_dir)
        if name.lower().endswith(".txt")
        and os.path.isfile(os.path.join(dataset_dir, name))
    ]
    return sorted(paths, key=lambda p: doc_sort_key(os.path.splitext(os.path.basename(p))[0]))


def tokenize(record):

    doc_id, text = record
    for position, term in enumerate(text.lower().split(), start=1):
        yield (term, doc_id), position


# Spark pipeline

def read_documents(sc, file_paths):
    """RDD of (doc_id, full text) for every file."""
    if any("," in p for p in file_paths):
        # wholeTextFiles takes a comma-separated path list, so a comma inside a
        # path would break it: read those files on the driver instead.
        records = []
        for path in file_paths:
            with open(path, "r", encoding="utf-8") as f:
                records.append((os.path.splitext(os.path.basename(path))[0], f.read()))
        return sc.parallelize(records)

    return (sc.wholeTextFiles(",".join(file_paths))
              .map(lambda kv: (os.path.splitext(os.path.basename(kv[0]))[0], kv[1])))


def build_positional_index(sc, file_paths):

    # (doc_id, text)
    documents = read_documents(sc, file_paths)

    # ((term, doc_id), position)
    term_positions = documents.flatMap(tokenize)

    # ((term, doc_id), [sorted positions])
    positions_per_doc = term_positions.groupByKey().mapValues(sorted)

    # (term, [(doc_id, [positions]), ...])
    index = (positions_per_doc
             .map(lambda kv: (kv[0][0], (kv[0][1], kv[1])))
             .groupByKey()
             .mapValues(lambda postings: sorted(postings, key=lambda p: doc_sort_key(p[0])))
             .sortByKey())

    return documents, index

def display_index(index_items):

    if not index_items:
        print("The positional index is empty.")
        return

    width = max(len(term) for term, _ in index_items) + 2
    print("=" * 72)
    print("POSITIONAL INDEX  (term -> document: token positions)")
    print("=" * 72)
    for term, postings in index_items:
        entry = "; ".join("{}: {}".format(doc, ", ".join(map(str, pos))) for doc, pos in postings)
        print(term.ljust(width) + entry)
    print("=" * 72)



def save_index(index_items, output_path):

    index_dict = {term: {doc: pos for doc, pos in postings} for term, postings in index_items}
    os.makedirs(os.path.dirname(os.path.abspath(output_path)), exist_ok=True)
    with open(output_path, "w", encoding="utf-8") as out:
        json.dump(index_dict, out, indent=2)


def main(dataset_dir=None, output_dir=None):
    """
    Build the positional index of every .txt file in dataset_dir with Spark and
    save it as <output_dir>/positional_index.json.
    Both arguments are optional: the defaults are the project's Dataset and
    output folders.
    """
    dataset_dir = dataset_dir or DATA_DIR
    output_file = (os.path.join(output_dir, "positional_index.json")
                   if output_dir else OUTPUT_FILE)

    file_paths = list_documents(dataset_dir) if os.path.isdir(dataset_dir) else []
    if not file_paths:
        sys.exit("No document files (.txt) were found in: " + dataset_dir)

    # Spark's Python workers must use the same interpreter as this program.
    os.environ.setdefault("PYSPARK_PYTHON", sys.executable)
    os.environ.setdefault("PYSPARK_DRIVER_PYTHON", sys.executable)

    spark = (SparkSession.builder
             .appName("PositionalIndex")
             .master("local[*]")
             .getOrCreate())
    try:
        sc = spark.sparkContext
        sc.setLogLevel("ERROR")

        documents, index = build_positional_index(sc, file_paths)
        index_items = index.collect()

        display_index(index_items)
        print("Documents processed : {}".format(len(file_paths)))
        print("Distinct terms      : {}".format(len(index_items)))

        save_index(index_items, output_file)
        print("Positional index saved to: {}".format(output_file))
    finally:
        spark.stop()


if __name__ == "__main__":
    main()